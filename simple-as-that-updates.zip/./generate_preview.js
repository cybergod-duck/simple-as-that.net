import fs from 'fs';
import path from 'path';

const htmlContent = `
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing Matrix - Deep Purple</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'neon-cyan': '#00F0FF',
                        'neon-green': '#00FF00',
                        'neon-pink': '#FF003C',
                    }
                }
            }
        }
    </script>
    <style>
        body { background-color: #000; color: #fff; font-family: system-ui, -apple-system, sans-serif; overflow-x: hidden; }
        
        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(30px) scale(0.95); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        
        .card-entrance {
            animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        .perspective-1000 {
            perspective: 1000px;
        }
    </style>
</head>
<body class="min-h-screen py-16 px-4 flex flex-col items-center bg-black">
    
    <div class="text-center mb-16 relative w-full flex flex-col items-center">
        <!-- Brand Header -->
        <h1 class="text-xl md:text-2xl font-black uppercase tracking-[0.3em] text-white mb-6 bg-purple-900/50 border border-purple-500/50 px-8 py-2 rounded-full shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            Simple As That
        </h1>

        <div class="absolute top-10 left-1/2 -translate-x-1/2 w-64 h-32 blur-[80px] pointer-events-none bg-purple-600/30 mix-blend-screen"></div>

        <h2 class="text-4xl md:text-5xl font-black tracking-tighter mb-4 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">
            Architecture Selection
        </h2>
        <p class="text-lg font-light tracking-wide max-w-2xl text-center text-purple-200/60">
            Optimized for Your Space. Select your foundational build.
        </p>
    </div>

    <!-- 5-Column Grid -->
    <div class="w-full max-w-[1600px] grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-5 perspective-1000 z-10">
        
        <!-- Tier 1 -->
        <div class="card-entrance flex flex-col justify-between group relative p-6 rounded-2xl cursor-pointer transition-all duration-500 bg-[#2a0e4a] border-2 border-purple-500 hover:bg-[#32115a] hover:border-cyan-400 hover:-translate-y-2 shadow-[0_0_15px_rgba(0,255,255,0.15)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)]">
            <div class="absolute -inset-2 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none bg-cyan-500/30 -z-10"></div>
            <div class="flex-grow">
                <h3 class="relative z-10 text-xl font-bold mb-2 text-purple-100">Landing Page</h3>
                <div class="relative z-10 flex items-baseline gap-1 mb-6">
                    <span class="text-4xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-200 to-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">$99</span>
                </div>
                <div class="relative z-10 flex items-center justify-between gap-2 py-3 mb-6 border-y -mx-2 px-2 border-purple-500/70 bg-purple-950/80 rounded-lg shadow-inner">
                    <div class="flex flex-col"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Speed</span><span class="text-sm font-mono font-bold text-white">0.6s</span></div>
                    <div class="w-px h-6 bg-purple-500/50"></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Lighthouse</span><span class="text-sm font-mono font-bold text-white">85/100</span></div>
                </div>
                <ul class="relative z-10 space-y-3 mb-6">
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Mobile-Optimized SP</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Local SEO Baseline</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Vercel Edge</li>
                </ul>
                <div class="mt-auto mb-6 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 bg-black/50 border-purple-500/60 text-cyan-300 group-hover:border-cyan-400 group-hover:bg-cyan-900/40 shadow-[inset_0_0_10px_rgba(168,85,247,0.2)]">Demo: Neon-V1</div>
            </div>
            <div class="relative z-10 w-full py-4 text-center rounded-xl font-bold text-sm uppercase tracking-widest transition-all border bg-purple-900/80 text-purple-200 border-purple-500/80 group-hover:border-cyan-400 group-hover:text-cyan-300 group-hover:bg-purple-800 shadow-[0_0_10px_rgba(168,85,247,0.3)]">Select</div>
        </div>

        <!-- Tier 2 -->
        <div class="card-entrance flex flex-col justify-between group relative p-6 rounded-2xl cursor-pointer transition-all duration-500 bg-[#2a0e4a] border-2 border-purple-500 hover:bg-[#32115a] hover:border-cyan-400 hover:-translate-y-2 shadow-[0_0_15px_rgba(0,255,255,0.15)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)]" style="animation-delay: 150ms;">
            <div class="absolute -top-4 left-4 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border bg-purple-900 text-cyan-400 border-cyan-500/50 shadow-[0_0_15px_rgba(0,255,255,0.4)] z-20">Most Popular</div>
            <div class="absolute -inset-2 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none bg-cyan-500/30 -z-10"></div>
            <div class="flex-grow">
                <h3 class="relative z-10 text-xl font-bold mb-2 text-purple-100">Starter Platform</h3>
                <div class="relative z-10 flex items-baseline gap-1 mb-6">
                    <span class="text-4xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-200 to-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">$199</span>
                </div>
                <div class="relative z-10 flex items-center justify-between gap-2 py-3 mb-6 border-y -mx-2 px-2 border-purple-500/70 bg-purple-950/80 rounded-lg shadow-inner">
                    <div class="flex flex-col"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Speed</span><span class="text-sm font-mono font-bold text-white">0.4s</span></div>
                    <div class="w-px h-6 bg-purple-500/50"></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Lighthouse</span><span class="text-sm font-mono font-bold text-white">95/100</span></div>
                </div>
                <ul class="relative z-10 space-y-3 mb-6">
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> 3-Page Hierarchy</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Brand Lock™</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Dynamic Capture</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Advanced JSON-LD</li>
                </ul>
                <div class="mt-auto mb-6 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 bg-black/50 border-purple-500/60 text-cyan-300 group-hover:border-cyan-400 group-hover:bg-cyan-900/40 shadow-[inset_0_0_10px_rgba(168,85,247,0.2)]">Demo: Atlas-Core</div>
            </div>
            <div class="relative z-10 w-full py-4 text-center rounded-xl font-bold text-sm uppercase tracking-widest transition-all border bg-purple-900/80 text-purple-200 border-purple-500/80 group-hover:border-cyan-400 group-hover:text-cyan-300 group-hover:bg-purple-800 shadow-[0_0_10px_rgba(168,85,247,0.3)]">Select</div>
        </div>

        <!-- Tier 3 (Selected) -->
        <div class="card-entrance flex flex-col justify-between group relative p-6 rounded-2xl cursor-pointer transition-all duration-500 bg-purple-950 border-2 border-purple-400 shadow-[0_0_40px_rgba(0,255,255,0.6),inset_0_0_20px_rgba(168,85,247,0.4)] scale-[1.05] -translate-y-4 z-30" style="animation-delay: 300ms;">
            <div class="absolute -top-4 right-4 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border bg-pink-600 text-white border-pink-400 shadow-[0_0_15px_rgba(255,0,255,0.8)] z-20">Best Value</div>
            <div class="absolute -inset-2 rounded-3xl blur-xl opacity-100 transition-opacity duration-700 pointer-events-none bg-cyan-500/30 -z-10"></div>
            <div class="flex-grow">
                <h3 class="relative z-10 text-xl font-bold mb-2 text-purple-100">Essential Growth</h3>
                <div class="relative z-10 flex items-baseline gap-1 mb-6">
                    <span class="text-4xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-200 to-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">$499</span>
                </div>
                <div class="relative z-10 flex items-center justify-between gap-2 py-3 mb-6 border-y -mx-2 px-2 border-purple-500/70 bg-purple-950/80 rounded-lg shadow-inner">
                    <div class="flex flex-col"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Speed</span><span class="text-sm font-mono font-bold text-white">0.3s</span></div>
                    <div class="w-px h-6 bg-purple-500/50"></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Lighthouse</span><span class="text-sm font-mono font-bold text-white">100/100</span></div>
                </div>
                <ul class="relative z-10 space-y-3 mb-6">
                    <li class="flex items-start text-xs leading-relaxed text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Lead-Capture UX</li>
                    <li class="flex items-start text-xs leading-relaxed text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Success Sections</li>
                    <li class="flex items-start text-xs leading-relaxed text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Programmatic State</li>
                    <li class="flex items-start text-xs leading-relaxed text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Compliance Shield</li>
                </ul>
                <div class="mt-auto mb-6 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 bg-black/50 border-purple-500/60 text-cyan-300 group-hover:border-cyan-400 group-hover:bg-cyan-900/40 shadow-[inset_0_0_10px_rgba(168,85,247,0.2)]">Demo: Conversion-X</div>
            </div>
            <div class="relative z-10 w-full py-4 text-center rounded-xl font-bold text-sm uppercase tracking-widest transition-all border bg-cyan-500 text-black border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.6)]">Selected Baseline</div>
        </div>

        <!-- Tier 4 -->
        <div class="card-entrance flex flex-col justify-between group relative p-6 rounded-2xl cursor-pointer transition-all duration-500 bg-[#2a0e4a] border-2 border-purple-500 hover:bg-[#32115a] hover:border-cyan-400 hover:-translate-y-2 shadow-[0_0_15px_rgba(0,255,255,0.15)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)]" style="animation-delay: 450ms;">
            <div class="absolute -inset-2 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none bg-cyan-500/30 -z-10"></div>
            <div class="flex-grow">
                <h3 class="relative z-10 text-xl font-bold mb-2 text-purple-100">Pro Engine</h3>
                <div class="relative z-10 flex items-baseline gap-1 mb-6">
                    <span class="text-4xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-200 to-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">$999</span>
                </div>
                <!-- Metrics and lines omitted for brevity... matching structure -->
                <div class="relative z-10 flex items-center justify-between gap-2 py-3 mb-6 border-y -mx-2 px-2 border-purple-500/70 bg-purple-950/80 rounded-lg shadow-inner">
                    <div class="flex flex-col"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Speed</span><span class="text-sm font-mono font-bold text-white">0.2s</span></div>
                    <div class="w-px h-6 bg-purple-500/50"></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Lighthouse</span><span class="text-sm font-mono font-bold text-white">100/100</span></div>
                </div>
                <ul class="relative z-10 space-y-3 mb-6">
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Growth Strategy</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> SGE Optimization</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Headless CMS</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Priority SLA</li>
                </ul>
                <div class="mt-auto mb-6 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 bg-black/50 border-purple-500/60 text-cyan-300 group-hover:border-cyan-400 group-hover:bg-cyan-900/40 shadow-[inset_0_0_10px_rgba(168,85,247,0.2)]">Demo: Synergy-Pro</div>
            </div>
            <div class="relative z-10 w-full py-4 text-center rounded-xl font-bold text-sm uppercase tracking-widest transition-all border bg-purple-900/80 text-purple-200 border-purple-500/80 group-hover:border-cyan-400 group-hover:text-cyan-300 group-hover:bg-purple-800 shadow-[0_0_10px_rgba(168,85,247,0.3)]">Select</div>
        </div>

        <!-- Tier 5 -->
        <div class="card-entrance flex flex-col justify-between group relative p-6 rounded-2xl cursor-pointer transition-all duration-500 bg-[#2a0e4a] border-2 border-purple-500 hover:bg-[#32115a] hover:border-cyan-400 hover:-translate-y-2 shadow-[0_0_15px_rgba(0,255,255,0.15)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)]" style="animation-delay: 600ms;">
            <div class="absolute -inset-2 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none bg-cyan-500/30 -z-10"></div>
            <div class="flex-grow">
                <h3 class="relative z-10 text-xl font-bold mb-2 text-cyan-300 drop-shadow-[0_0_8px_rgba(0,255,255,0.5)]">Elite Cyber-Arc</h3>
                <div class="relative z-10 flex items-baseline gap-1 mb-6">
                    <span class="text-4xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-200 to-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">$1,999</span>
                </div>
                <div class="relative z-10 flex items-center justify-between gap-2 py-3 mb-6 border-y -mx-2 px-2 border-purple-500/70 bg-purple-950/80 rounded-lg shadow-inner">
                    <div class="flex flex-col"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Speed</span><span class="text-sm font-mono font-bold text-white">0.1s</span></div>
                    <div class="w-px h-6 bg-purple-500/50"></div>
                    <div class="flex flex-col items-end"><span class="text-[9px] font-bold tracking-widest uppercase text-cyan-400 drop-shadow-[0_0_3px_rgba(0,255,255,0.5)]">Lighthouse</span><span class="text-sm font-mono font-bold text-white">100/100</span></div>
                </div>
                <ul class="relative z-10 space-y-3 mb-6">
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Enterprise Arch</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Competitor Analysis</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> Semantic Logo Gen</li>
                    <li class="flex items-start text-xs leading-relaxed text-purple-200 group-hover:text-white transition-colors"><span class="text-cyan-400 mr-2 opacity-90">•</span> State Compliance</li>
                </ul>
                <div class="mt-auto mb-6 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 bg-black/50 border-purple-500/60 text-cyan-300 group-hover:border-cyan-400 group-hover:bg-cyan-900/40 shadow-[inset_0_0_10px_rgba(168,85,247,0.2)]">Demo: Cyber-God</div>
            </div>
            <div class="relative z-10 w-full py-4 text-center rounded-xl font-bold text-sm uppercase tracking-widest transition-all border bg-purple-900/80 text-purple-200 border-purple-500/80 group-hover:border-cyan-400 group-hover:text-cyan-300 group-hover:bg-purple-800 shadow-[0_0_10px_rgba(168,85,247,0.3)]">Select</div>
        </div>

    </div>
</body>
</html>
`;

fs.writeFileSync(path.join(process.cwd(), 'pricing_preview.html'), htmlContent);
console.log('Premium Purple preview generated.');
